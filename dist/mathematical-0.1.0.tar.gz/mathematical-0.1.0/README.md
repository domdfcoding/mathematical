# mathematical
Mathematical tools for python

Includes tools for calculating mean, median and standard deviation of rows in data frames, detection of outliers, and statistical calculations
